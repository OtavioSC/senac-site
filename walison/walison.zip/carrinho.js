function adicionarAoCarrinho() {
    alert("Produto adicionado ao carrinho!");
}
